import userModel from "../model/userModel.js"
import bcrypt from "bcrypt"
import jwt from "jsonwebtoken"
import { config } from "dotenv";
config()

export const userSignup = async (req, res) => {
    try {
        const { username, mobile, password, email,role } = req.body
        console.log("")
        if (!username || !password || !mobile || !email || !role) {
            return res.status(400).send({ error: "Provide all required field" })
        }
        else {
            const isUser = await userModel.findOne({ email })
            if (isUser) {
                return res.status(400).send({ error: "User already Registerd" })
            }
            else {
                const hashedPassword = bcrypt.hashSync(password, 10)
                const user = new userModel({ ...req.body, password: hashedPassword })
                let response = await user.save()
                res.status(201).send({ message: "Signup successfully" })
            }
        }
    } catch (err) {
        return res.status(500).send({ error: "Something Went Wrong ", errorMsg: err.message })
    }
}



export const userLogin = async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).send({ error: "Please provide all the fields before login" });
        }

        const user = await userModel.findOne({ email });
        if (user) {
            // Compare passwords using bcrypt
            const matchPassword = bcrypt.compareSync(password, user.password);
            if (matchPassword) {
                const { _id: userId, role } = user; // Destructure the user's ID and role
                const token = jwt.sign({ userId, role }, "secret", { expiresIn: "7d" }); // Include the role in the token

                // Set the token as an HTTP-only cookie
                res.cookie("auth_token", token, { maxAge: 1000 * 60 * 60 * 24 * 7, httpOnly: true });

                // Respond with a success message, token, and role
                return res.status(200).send({
                    message: "Login successful",
                    token: token,
                    role: role, // Send the role as part of the response
                });
            } else {
                return res.status(401).send({ error: "Password is not matching" });
            }
        } else {
            return res.status(401).send({ error: "User not registered" });
        }
    } catch (err) {
        return res.status(500).send({ error: "Something went wrong", errorMsg: err.message });
    }
};

// export const userLogin = async (req, res) => {
//     try {
//         const { email, password } = req.body
//         if (!email || !password) {
//             return res.status(400).send({ error: "provide all the fields before login" })
//         }
//         else {
//             const response = await userModel.findOne({ email })
//             if (response) {
//                 console.log("test");
//                 //bcrypt logic
//                 let matchPassword = bcrypt.compareSync(password, response.password)
//                 if (matchPassword) {
                    
                   
//                     const userId = response._id
//                     const token = jwt.sign({ userId }, "secret" , { expiresIn: "7d" }) //use your own secret key process.env.JWT_Secret
//                     if (token) {
//                         console.log("test")
//                     }
//                     res.cookie("auth_token", token, { maxAge: 1000 * 60 * 60 * 24 * 7, httpOnly: true })
//                     return res.status(200).send({ message: "Login successfull", token : token })
//                 }
//                 else {
//                     return res.status(401).send({ error: "Password is not matching" })
//                 }
//             }
//             else {
//                 return res.status(401).send({ error: "user not registerd" })
//             }
//         }
//     } catch (err) {
//         res.status(500).send({ error: "something went wrong", errorMsg: err.message })
//     }
// }

export const getUser = async (req, res) => {
    try {
        const { userId } = req
        const userDetails = await userModel.findById(userId).select("-_id -password -__v")
        if (!userDetails) {
            return res.status(403).send({ error: "User is not available" })
        }
        else return res.status(200).send(userDetails)
    }
    catch (err) {
        res.status(500).send({ error: "something went wrong", errorMsg: err.message })
    }
}

export const userLogout = async (req, res) => {
    try {
        res.clearCookie("auth_token")
        return res.status(200).send({ message: "Logout Successfull" })
    } catch (error) {
        res.status(500).send({ error: "Something Went Wrong", errMsg: error.message })
    }
}

export const updateUser = async (req, res) => {
    try {
        const userId = req.userId
        const data = req.body
        const response = await userModel.findByIdAndUpdate(userId, { $set: { ...data } })
            .select("-_id -password -__v")
        res.status(200).send({ message: "User Details Updated", userData: { response } })
    } catch (err) {
        res.status(500).send({ error: "Something went wrong", errorMsg: err.message })
    }
}

export const deleteUser = async (req, res) => {
    try {
        const userId = req.userId
        await userModel.findByIdAndDelete(userId)
        res.clearCookie("auth_token")
        res.status(200).send({ message: "User Deleted" })
    } catch (err) {
        res.status(500).send({ error: "Something went wrong", errorMsg: err.message })
    }
}

export const chatUsers = async (req, res) => {
    try {
        const userId = req.userId
        const user = await userModel.findById(userId)
        const chatUsers = await userModel.find({ email: { $ne: user.email } })
        res.status(200).send({ chatUsers })
    } catch (err) {
        res.status(500).send({ error: "Something went Wrong", errorMsg: err.message })
    }
}